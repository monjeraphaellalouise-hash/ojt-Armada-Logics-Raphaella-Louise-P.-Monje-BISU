const options = document.querySelectorAll(".option");

options.forEach(option => {
    option.addEventListener("click", () => {
        // get what part and image was clicked
        const part = option.dataset.part;
        const image = option.dataset.image;

        // show the armor in the preview
        const layer = document.getElementById(part);
        layer.src = image;
        layer.style.display = "block";

        // remove highlight from same armor type
        options.forEach(o => {
            if (o.dataset.part === part) o.classList.remove("selected");
        });

        // highlight selected item
        option.classList.add("selected");
    });
});